import microbit as mb
from microbit import *

message = "Fail"
basic.show_string(message)