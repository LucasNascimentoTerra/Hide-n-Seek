
from microbit import *
basic.show_number(8)
basic.pause(500)
basic.clear_screen()